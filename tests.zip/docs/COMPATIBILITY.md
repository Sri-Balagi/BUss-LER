# Compatibility Matrix (BizOS v4.0.0)

BizOS is continuously tested against specific runtime dependency versions to guarantee architectural stability.

## Core Runtimes
| Dependency | Minimum Version | Recommended | Notes |
| :--- | :--- | :--- | :--- |
| **Python** | `>= 3.12.0` | `3.12.1` | Python 3.14 breaks `mutmut` testing logic. Stick to 3.12 for dev. |
| **OS Support** | Linux, macOS, WSL2 | Linux (Docker) | Native Windows execution works but is not officially tested for production. |

## Data Persistence & External APIs
| Dependency | Minimum Version | Tested Version | Notes |
| :--- | :--- | :--- | :--- |
| **Supabase (PostgreSQL)** | `>= 2.31.0` | `2.31.0` | Requires `pgvector` extension enabled for semantic caching. |
| **Qdrant** | `>= 1.18.0` | `1.18.0` | Used for massive vector retrieval (Memory Engine). |
| **FastAPI** | `>= 0.138.1` | `0.138.1` | Core API Framework. |
| **Pydantic** | `>= 2.13.4` | `2.13.4` | Strictly required for `EnterpriseContext` validation. |

## LLM Integrations (Forthcoming in M5)
| Provider | Supported Models |
| :--- | :--- |
| **OpenAI** | `gpt-4o`, `gpt-4-turbo` |
| **Google Gemini**| `gemini-1.5-pro` |
| **Anthropic** | `claude-3-opus`, `claude-3.5-sonnet` |

*Note: While LLM integration bounds exist, M4 utilizes mocks for deterministic architectural testing.*

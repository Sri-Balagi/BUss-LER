# BizOS v4.0.0 Release Checklist

Before tagging the `v4.0.0` release on GitHub, verify the following:

## 1. Codebase Hygiene
- [x] All obsolete TODOs removed.
- [x] Unused imports removed (`ruff check --fix`).
- [x] Code formatted properly (`ruff format`).
- [x] Type hints are fully passing (`mypy` or `pyright`).

## 2. Validation & Quality Gates
- [x] Unit, Boundary, and Integration tests passing (442/442).
- [x] Core Business Logic coverage verified at >= 95% (Actual: 96%).
- [x] Mutation tests verified to execute correctly (AST generation passes).
- [x] Benchmarks show no regressions against v3 baselines.

## 3. Documentation
- [x] `RELEASE_NOTES_v4.md` generated.
- [x] `CHANGELOG.md` updated with v4.0.0 section.
- [x] `ADR/004-context-engine.md` finalized and approved.
- [x] `DEPLOYMENT.md` updated with v4 requirements.
- [x] `MIGRATION_v3_to_v4.md` created for upgrading users.
- [x] `ARCHITECTURE_FREEZE_v4.md` published.
- [x] `COMPATIBILITY.md` verified against current dependencies.
- [x] `RUNBOOK.md` established for operations.
- [x] `release_manifest.json` correctly generated with v4 schema details.
- [x] `M4_SUMMARY.md` completed to close out the milestone.

## 4. Release Execution
- [x] Update `pyproject.toml` version to `4.0.0`.
- [ ] Create signed Git Tag: `git tag -a v4.0.0 -m "Release v4.0.0 (Enterprise Context Engine)"`.
- [ ] Push tags: `git push origin v4.0.0`.
- [ ] Create GitHub Release using `RELEASE_NOTES_v4.md`.

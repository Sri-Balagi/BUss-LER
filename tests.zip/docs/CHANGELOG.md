# Changelog

All notable changes to the BizOS project will be documented in this file.

The format is based on [Keep a Changelog](https://keepachangelog.com/en/1.0.0/), and this project adheres to [Semantic Versioning](https://semver.org/spec/v2.0.0.html).

## [4.0.0] - 2026-06-28
### Added
- **Enterprise Context Engine**: A core architectural component for retrieving, building, and strategizing entity context.
- **Context Dependency Graph**: A DAG-based execution runner that parallelizes ContextProviders while adhering to strict dependency ordering.
- **Context Strategy & Policies**: Configurable policies (e.g. `RecencyBiasStrategy`, `TokenOptimizedStrategy`) to compress and rank context into finite AI token windows.
- **Provider Registry**: Pluggable interface for registering arbitrary internal and external data providers to the Context Engine.
- **Immutable Context Envelope**: Implementation of the `EnterpriseContext` pydantic envelope enforcing immutability after generation.

### Changed
- Decoupled the state memory models from the raw LLM integration boundaries.
- Upgraded testing infrastructure to formally isolate HTTP and external API boundaries from Business Logic coverage reporting.

### Fixed
- Addressed potential latency bottlenecks by migrating synchronous data ingestion pipelines into the asynchronous `DependencyGraph` runner.

## [2.0.0] - 2026-06-25
### Added
- Memory Engine architecture release.

## [1.0.0] - 2026-06-20
### Added
- Initial project creation and Entity Core architecture.

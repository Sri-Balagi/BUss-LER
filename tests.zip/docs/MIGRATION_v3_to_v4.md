# Migration Guide: v3 to v4

BizOS v4.0.0 (Enterprise Context Engine) introduces a significant architectural shift in how Context is retrieved and injected into the AI Kernel.

## Upgrade Steps

1. **Update Dependencies**: 
   Ensure `uv` is installed, and run `uv pip install --system -e .` to synchronize your python environment.
2. **Apply Migrations**: 
   The database schema includes new indexes for Context lookup performance.
   `supabase db push` (or run the equivalent SQL script).
3. **Environment Updates**: 
   No new environment variables are strictly required for v4 to boot, but caching options are now available for configuration.

## Migration Sequence

Code interacting directly with `MemoryService` or injecting context into prompts must be updated.

### 1. Context Object Migration
**v3.x**:
```python
raw_context = await memory.get_recent(entity_id)
# Passed directly to PromptManager
prompt = prompt_manager.build(raw_context)
```

**v4.0**:
```python
from app.services.context_engine import ContextEngine

# 1. Generate Immutable Context envelope
enterprise_context = await context_engine.build_context(entity_id)

# 2. Apply a ContextStrategy to compress/rank it for the LLM
ranked_window = await context_engine.apply_strategy(enterprise_context, strategy="token_optimized")

# 3. Pass to PromptManager
prompt = prompt_manager.build(ranked_window)
```

### Breaking Changes
- `bizos.models.context` objects from v3 have been removed or completely restructured into `EnterpriseContext`.
- Context Providers now **must** inherit from `app.services.providers.base.ContextProvider` and be registered in the `ProviderRegistry`. Ad-hoc retrieval scripts outside the Graph will fail strict typing tests.

## Rollback Strategy
If you experience downstream failures:
- Application Rollback: Revert your Docker image or Git tag to `v3.0.x`.
- Database Rollback: The new indexes added in v4 do not break v3 read compatibility. However, if data shape was mutated, run the downward migration script to revert schema constraints.

# ADR-004: Why Optimistic Concurrency

## Context
Digital Twins will be updated frequently by both human users and autonomous AI agents operating concurrently.

## Problem
How do we prevent lost updates and race conditions when multiple agents try to update the same Twin simultaneously?

## Decision
We chose **Optimistic Concurrency Control** via a `twin_version` integer. Every update requires the client to provide the expected `twin_version`. The database RPC (`update_twin_with_snapshot`) verifies the version before committing.

## Alternatives Considered
- Pessimistic Locking: Too slow, prone to deadlocks, and reduces throughput for high-frequency AI agents.
- Last-Write-Wins: Unacceptable for an AI OS, as critical AI insights could be overwritten silently.

## Consequences
- Clients receive an HTTP 409 Conflict if they submit a stale version.
- Clients must handle retries logic.

## Future Impact
This guarantees absolute data integrity for the Twin History, ensuring the Memory Engine always processes a linear, chronological sequence of valid states.

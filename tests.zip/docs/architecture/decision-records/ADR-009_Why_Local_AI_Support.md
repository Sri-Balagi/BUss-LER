# ADR-009: Why Local AI Support

## Context
BizOS aims to be a competitive Gemini XPRIZE submission, but also an Enterprise-grade Operating System.

## Problem
Many enterprises cannot send sensitive proprietary data (Digital Twins, Memories) to cloud LLM providers due to compliance and security constraints.

## Decision
BizOS architecture must support **Local AI Inference** via the AI Kernel (e.g., using Ollama, vLLM, or local MLX instances).

## Alternatives Considered
- Cloud-only: Alienates a massive segment of enterprise users.

## Consequences
- The AI Kernel must be provider-agnostic.
- We must support smaller models (e.g., Llama 3 8B, Gemma 2) that can run on consumer/enterprise hardware.

## Future Impact
This positions BizOS as a highly secure, privacy-first AI OS, which is a massive competitive advantage.

# ADR-010: Why Domain-Agnostic Design

## Context
Digital Twins are traditionally used for IoT devices (e.g., manufacturing).

## Problem
If we tie our data models to specific domains (e.g., "Company", "Employee", "Sensor"), we limit the scope of the Operating System.

## Decision
We adopted a **Domain-Agnostic Design**. The core `Entity` and `DigitalTwin` models have no domain-specific fields. All domain knowledge is stored in the schemaless JSONB `state` and `metadata` fields.

## Alternatives Considered
- Strongly typed relational tables for every object type: Inflexible, requires constant schema migrations for every new feature.

## Consequences
- The OS can represent a Startup, an IoT Sensor, a NPC in a game, or a Financial Portfolio using the exact same underlying architecture.
- We rely on AI or higher-level schemas to interpret the JSONB state.

## Future Impact
This makes BizOS an infinitely extensible platform, capable of adapting to any industry or use case without modifying the core C codebase.

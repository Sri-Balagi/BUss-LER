# ADR-001: Why Digital Twins

## Context
BizOS is designed to be an AI-native operating system. Traditional CRUD applications focus on static data models. AI systems need dynamic, evolving representations of real-world or digital entities to reason about them effectively.

## Problem
How do we represent state in a way that allows AI models to understand an entity's current context, historical progression, and future potential?

## Decision
We adopted the **Digital Twin** pattern. Every significant business object (Entity) has a corresponding Digital Twin that holds its current state, metadata, and an immutable history of changes.

## Alternatives Considered
- Standard relational tables (too rigid, hard to version).
- Event Sourcing (too complex for initial querying and AI reasoning).

## Consequences
- AI agents can fetch a Twin to understand the complete context of an entity.
- We must enforce atomic updates to the Twin to ensure consistency.

## Future Impact
The Digital Twin will become the central anchor for Memory, Goals, and Simulation engines.

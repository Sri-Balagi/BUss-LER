# ADR-007: Why AI Kernel

## Context
The system will need to communicate with LLMs to generate text, summarize memories, and make agentic decisions.

## Problem
Hardcoding API calls to Gemini or OpenAI tightly couples the OS to a specific provider and prevents fallback routing, cost control, or local model execution.

## Decision
We will build an **AI Kernel** abstraction layer. All AI requests must route through this Kernel, which handles Provider Routing, Prompt Management, and Context Assembly.

## Alternatives Considered
- Direct API integration: Faster initially, but leads to vendor lock-in.
- LangChain: Too bloated, unpredictable abstractions, and difficult to debug in production.

## Consequences
- We must build and maintain our own abstraction layer.
- We gain complete control over the AI lifecycle, enabling cost monitoring and safety filters.

## Future Impact
The AI Kernel will be the heart of BizOS, eventually supporting localized inference, specialized fine-tuned models, and intelligent routing based on task complexity.

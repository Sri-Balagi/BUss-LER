# ADR-003: Why Repository Pattern

## Context
The application needs to interact with the database. Fast API routers often embed database logic directly, leading to tightly coupled code.

## Problem
How do we ensure the business logic and API layers remain decoupled from the persistence layer?

## Decision
We implemented a strict **Repository Pattern**. Repositories encapsulate all database access (Supabase/SQL). Services call Repositories. Routers call Services.

## Alternatives Considered
- Active Record (Django/SQLAlchemy style): Couples business objects to database schemas.
- Inline DB calls in Routers: Unmaintainable and impossible to mock effectively.

## Consequences
- The codebase is highly testable via mock repositories.
- Swapping the underlying database (e.g., migrating off Supabase) only requires rewriting the Repository layer.

## Future Impact
This ensures that as BizOS scales and introduces specialized storage (like Qdrant for vectors), the service layer remains clean and unaware of the underlying storage specifics.

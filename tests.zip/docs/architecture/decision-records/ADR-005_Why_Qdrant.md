# ADR-005: Why Qdrant

## Context
Milestone 2 (Memory Engine) will require semantic search and vector storage for AI embeddings.

## Problem
Where do we store and query millions of high-dimensional vectors efficiently?

## Decision
We have selected **Qdrant** as our primary vector database.

## Alternatives Considered
- pgvector (Supabase): Good for co-location, but Qdrant offers better horizontal scalability, specific vector optimization, and memory-mapping features for large-scale AI workloads.
- Pinecone: Cloud-only, which violates our requirement for Local AI and self-hosted Enterprise deployments.

## Consequences
- We must maintain an additional infrastructure component.
- The Repository layer must be extended to interact with Qdrant.

## Future Impact
Qdrant's payload filtering capabilities will allow us to combine semantic search with Digital Twin metadata filtering, enabling complex Context Engine queries.

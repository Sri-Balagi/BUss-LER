# ADR-002: Why Supabase/PostgreSQL

## Context
The Digital Twin System requires robust storage for relational entities, highly flexible schemaless storage for twin state, and robust concurrency control.

## Problem
Choosing the right database technology that balances relational integrity with flexible JSON storage and scalability.

## Decision
We selected **PostgreSQL** via **Supabase**. We use PostgreSQL's `JSONB` for the twin `state` and `metadata`, allowing schema-less flexibility while retaining ACID guarantees.

## Alternatives Considered
- MongoDB / NoSQL: Excellent for JSON, but lacks robust relational integrity for user/entity mapping.
- DynamoDB: Fast, but complex query patterns for analytical AI tasks.

## Consequences
- We benefit from robust constraints, RPC functions for atomic updates, and RLS for security.
- We rely on `JSONB` indexing for performance.

## Future Impact
Supabase provides built-in pgvector support, which perfectly aligns with our future Memory Engine (if we choose to co-locate vector storage) and offers real-time subscriptions for the Event-Driven Architecture.

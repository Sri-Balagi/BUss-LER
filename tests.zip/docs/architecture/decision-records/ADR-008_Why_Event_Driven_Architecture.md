# ADR-008: Why Event-Driven Architecture (Future)

## Context
Updating a Digital Twin should trigger subsequent asynchronous workflows, such as Memory summarization, Goal evaluation, and Agent notifications.

## Problem
Synchronous execution of these AI tasks during a Twin update would result in unacceptable API latency and timeouts.

## Decision
We will adopt an **Event-Driven Architecture** for AI background tasks. Twin mutations will publish events to an internal bus (or message queue) which background workers will consume.

## Alternatives Considered
- Synchronous processing: Fails under load; AI API calls are slow.
- Polling: Inefficient and introduces latency.

## Consequences
- Requires introducing a message broker (e.g., Redis Pub/Sub, RabbitMQ, or Kafka) in future milestones.
- Ensures the API remains lightning-fast for CRUD operations.

## Future Impact
This architecture enables distributed Agents to react to state changes in real-time without blocking the core system, paving the way for multi-agent simulation.

# BizOS v4.0.0 Release Notes (Enterprise Context Engine)

**Release Date:** June 2026
**Milestone:** 4

## Overview
BizOS v4.0.0 introduces the **Enterprise Context Engine**, a foundational layer that centralizes entity context processing, memory integration, and strategic ranking for downstream AI operations. This milestone solidifies the repository architecture and introduces rigorous validation mechanics to support BizOS as a long-term AI Operating System.

## Major Features

- **Context Dependency Graph**: A deterministic execution graph ensuring Context Providers run in parallel where possible, but strictly adhere to data dependency ordering (e.g. ActivityProvider waits for EntityProvider).
- **Immutable EnterpriseContext**: The `EnterpriseContext` object is mathematically immutable upon generation. Any mutations or downstream transformations occur via deterministic Builder structures.
- **Provider Registry & Isolation**: All 3rd party and internal data sources are wrapped in isolated `ContextProvider` classes that adhere to strict SLAs, fault-tolerance timeouts, and retry policies.
- **Strategic Ranking & Compression**: Injected context can now be strategically pruned, summarized, and ranked dynamically based on `ContextStrategy` policies to ensure LLM token windows are optimized efficiently.

## Architectural Improvements
- Completely decoupled the Context Engine from the LLM execution layer (`AI Kernel`).
- Achieved **96% Core Business Logic Coverage** and verified branch testing capabilities.
- Solidified the Event Bus integration for context invalidation patterns.

## Breaking Changes
- `bizos.models.context` objects from v3.0.0 have been fully replaced. Downstream processors must now consume the serialized `EnterpriseContext` envelope instead of direct dictionary structures.
- Context injection now strictly requires a registered `ContextStrategy`. Default fallbacks are provided, but strict typing is enforced.

## Known Limitations
- **Mutation Testing**: Local execution is currently blocked by Python 3.14 deprecation issues in the `mutmut` upstream library. It is strictly recommended to execute mutation tests via Docker (Python 3.12-slim) or GitHub Actions.
- **External Mocking**: End-to-end integration with third-party LLMs still utilizes mocked responses in the test suite to preserve determinism and prevent API cost overruns. Live plugin architectures are reserved for Milestone 5.

﻿# ADR-003: Provider-Agnostic AI Kernel

**Status:** Accepted
**Date:** 2026-06-26
**Deciders:** Principal Architect

---

## Context
Vendor lock-in to a single AI provider (Google Gemini) would make BizOS fragile to pricing changes, API deprecations, and capability gaps. Business domain logic should not change when the AI backend changes.

## Decision
Implement an abstract AI Kernel (AbstractAIKernel) with three capability methods:
- generate() — text generation
- embed() — vector embedding
- classify() — structured JSON classification

All AI provider implementations implement AbstractAIProvider. The kernel routes requests through a ProviderRouter that selects the active provider. Business logic never imports a specific provider.

## Consequences
- Google Gemini, OpenAI, or any LLM can be added without modifying business logic
- Providers can be swapped at runtime via configuration
- Classification responses are always validated as JSON (no free-form text)
- Initial implementation complexity is higher; justified by provider independence

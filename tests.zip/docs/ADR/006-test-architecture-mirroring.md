﻿# ADR-006: Test Architecture Mirroring

**Status:** Accepted
**Date:** 2026-06-29
**Deciders:** Principal Architect

---

## Context
Early test files were organized by test type (unit/, integration/, e2e/) rather than by architectural layer. This made it difficult to locate tests for a specific component and did not enforce ownership of tests alongside production code.

## Decision
Mirror the production package structure exactly in the test hierarchy:
- 	ests/runtime/ mirrors pp/runtime/
- 	ests/intelligence/ mirrors pp/intelligence/
- 	ests/infrastructure/ mirrors pp/infrastructure/
- 	ests/shared/ mirrors pp/shared/
- 	ests/certification/ contains cross-layer certification tests

## Consequences
- Tests are always co-located with the components they test
- Deleting a production package makes it obvious which tests to remove
- CI can run layer-specific test subsets (pytest tests/runtime/)
- Certification tests that span multiple layers are explicitly separated

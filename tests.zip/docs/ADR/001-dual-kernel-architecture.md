﻿# ADR-001: Dual-Kernel Architecture

**Status:** Accepted
**Date:** 2026-06-28
**Deciders:** Principal Architect

---

## Context
BizOS needs to serve two fundamentally different concerns: the *execution* of AI agent tasks (how agents do things) and the *intelligence* that guides those agents (what they should do and why). Early versions conflated these in a single service layer, leading to tight coupling and difficulty evolving either concern independently.

## Decision
Separate BizOS into two isolated kernels:
- **M5 Runtime OS Kernel** — manages execution, scheduling, budgeting, and session lifecycle
- **M6 Executive Intelligence Kernel** — manages intent, strategy, planning, and learning

The kernels communicate exclusively through a typed Runtime Bridge interface. Direct cross-kernel imports are prohibited.

## Consequences
- Each kernel can evolve, be tested, and be deployed independently
- Intelligence can be swapped or extended without touching Runtime internals
- The bridge interface becomes the only stable API surface between kernels
- Adds initial complexity; justified by long-term scalability

﻿# ADR-002: Repository Modernization from FastAPI Layout to AI OS Layout

**Status:** Accepted
**Date:** 2026-06-29
**Deciders:** Principal Architect

---

## Context
The original repository was scaffolded as a standard FastAPI web application with pp/api/, pp/services/, pp/repositories/, and pp/models/ folders. As BizOS evolved into a full AI Operating System, this structure no longer accurately reflected the architecture. Legacy folder names confused contributors and made architectural boundaries invisible.

## Decision
Refactor the repository from the FastAPI web application layout to a kernel-based AI OS layout:

| Old Structure | New Structure |
|--------------|--------------|
| pp/api/ | pp/interfaces/http/ |
| pp/services/ | pp/intelligence/ + pp/runtime/ |
| pp/repositories/ | pp/infrastructure/persistence/ |
| pp/models/ | Distributed to bounded contexts |

## Consequences
- Repository structure communicates architecture
- Legacy technical debt eliminated
- Import paths updated across entire codebase
- 367-test suite validated with zero regressions post-migration

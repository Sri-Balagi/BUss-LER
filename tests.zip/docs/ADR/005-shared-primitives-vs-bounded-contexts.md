﻿# ADR-005: Shared Primitives vs Bounded Context Models

**Status:** Accepted
**Date:** 2026-06-29
**Deciders:** Principal Architect

---

## Context
During M6 development, models were initially placed in a centralized pp/models/ package. This created hidden coupling between domains and made it unclear which kernel owned which data contract.

## Decision
Distribute all domain models to their owning bounded contexts:
- pp/intelligence/intake/intent/intent.py — Intent domain model
- pp/intelligence/strategy/goals/goal.py — Goal domain model
- pp/runtime/capabilities/models/ — Capability models
- etc.

Only genuinely universal primitives belong in pp/shared/:
- pp/shared/enums.py — cross-domain enumerations
- pp/shared/events/ — domain event bus and base event types
- pp/shared/exceptions/ — error hierarchy

## Consequences
- Models live beside the code that owns and evolves them
- Shared layer remains minimal and stable
- Repository analysis immediately reveals domain ownership
- Import analysis can detect boundary violations automatically

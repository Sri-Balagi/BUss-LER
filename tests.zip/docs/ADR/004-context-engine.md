﻿# ADR-004: Context Engine and EnterpriseContext Assembly

**Status:** Accepted
**Date:** 2026-06-26
**Deciders:** Principal Architect

---

## Context
AI models make poor decisions without sufficient context. BizOS needed a mechanism to assemble all relevant information about an entity (its intent, goals, memory, plans, recommendations, and state) into a single coherent context package that could be provided to the AI Kernel.

## Decision
Implement an EnterpriseContext model composed of ContextSection objects, each contributed by a registered AbstractContextProvider. A ContextAssembler orchestrates provider execution, caches results, and assembles the final context. The context is passed as a dictionary to the AI Kernel's prompt system.

## Consequences
- AI prompts are always grounded in real entity state
- New context sources (e.g., external data providers) can be registered without modifying the assembler
- Context is cached to avoid redundant I/O on repeated requests
- Context assembly is the most expensive operation in the system — caching is critical

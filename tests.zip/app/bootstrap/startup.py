"""Bootstrap startup wiring."""

"""Dependency Injection container setup."""

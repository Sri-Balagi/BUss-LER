"""Registry wiring."""

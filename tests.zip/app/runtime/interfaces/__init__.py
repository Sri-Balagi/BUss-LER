"""
Execution Kernel Interfaces
"""

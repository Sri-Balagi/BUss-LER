"""
Execution Kernel Session Subsystem
"""

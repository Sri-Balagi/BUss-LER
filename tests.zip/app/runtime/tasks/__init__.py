"""
Execution Kernel Task Subsystem
"""

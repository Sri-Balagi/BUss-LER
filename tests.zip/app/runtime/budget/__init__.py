"""
Execution Kernel Budget Subsystem
"""

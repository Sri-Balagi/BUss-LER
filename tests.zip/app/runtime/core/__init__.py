"""
Execution Kernel Core Subsystem
"""
